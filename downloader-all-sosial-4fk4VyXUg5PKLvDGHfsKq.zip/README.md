# Downloader All Sosial

voxy Ai I've made it public, so try it so you can download mp4 and audio. If we download mp4, the result will be a video. If we download MP3, the audio will come out and avoid errors. 

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Run the development server:
   ```bash
   npm run dev
   ```

3. Open your browser and navigate to the URL shown in the terminal.

## Project Information

- Generated with Yapi
- Project ID: 4fk4VyXUg5PKLvDGHfsKq
- Created: 2026-01-06T14:44:03.834Z
